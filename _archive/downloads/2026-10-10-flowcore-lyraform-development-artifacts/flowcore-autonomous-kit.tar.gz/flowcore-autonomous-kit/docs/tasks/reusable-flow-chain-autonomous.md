# Autonomous reusable Flow compiler-chain mission

## Authority

Execute this mission autonomously to completion. Normal commits and pushes to
the currently checked-out development branch are authorized at coherent green
checkpoints. The Git limits in the repository `AGENTS.md` remain binding.

Do not finish a Codex turn merely because one implementation slice is complete.
Continue to the next unfinished gate. If the outer supervisor starts a fresh
turn, recover from this task, the architecture plan, maturation ledger, run
state, Git history, and current worktree.

## Current reported checkpoint

The supplied 21 August 2026 transcript reports:

- Flowanalyst emits additive `flowcore.lowering_plan` version 1 operations.
- External operations contain source provenance, provider identity, convention,
  effect, carrier parameter types, return type, argument expression IDs, and a
  result symbol where applicable.
- Flowbind parses and structurally validates external plan operations against
  semantic binding requirements.
- Existing source-name profiles remain as transitional compatibility.
- The complete regression suite passed 52/52.
- The next intended slice is profile-free scalar external-call emission in
  Flowlower using a program with no recognized profile name.

These are reported facts, not permission to assume the checkout is healthy.
First inspect the current branch, worktree and recent history; run the relevant
focused gate and reconcile any newer work before editing.

## Final objective

A previously built Flowcore toolchain must compile new Flow programs into native
executables using only:

- the installed Flow compiler binaries;
- Flow source and imports;
- provider contracts and generated binding artifacts;
- explicit policies and provider selection;
- target/toolchain inputs such as LLVM and the native linker.

Adding an application or a supported native capability must not require:

- editing or rebuilding Flowcore's C++ compiler tools;
- adding an application/source-unit/profile name to any compiler stage;
- adding a handwritten LLVM emitter for that application;
- inferring authority from a symbol merely existing in a provider library.

The intended reusable chain is:

```text
Flow source
  -> Flowmini frontend bundle
  -> Flowanalyst semantic report and lowering plan
  -> Flowbind exact capability authorization
  -> Flowparallel execution plan
  -> Flowoptimize transformed plan
  -> Flowlower backend IR
  -> LLVM/native linker
  -> executable artifact
```

## Non-negotiable semantic boundaries

- Application behavior belongs in Flow source, not compiler fixture dispatch.
- Qualified source identity, provider identity, native symbol identity and
  contract identity remain distinct.
- `->` value placement and `=>` graph connection remain different semantics.
- Provider discovery is evidence, not authorization.
- Authorization covers the exact callable ABI contract, including provider,
  symbol, convention, parameter/result carrier types, effects and versioned
  contract/evidence identity.
- Unsupported operations fail explicitly with structured diagnostics and
  provenance. A stage must not guess from source-unit names.
- Published plans retain stable operation identity and provenance through
  downstream stages.
- Compatibility paths may remain temporarily only while covered migration tests
  exist and their removal gate is documented.

## Execution program

### Gate 1 — Verify and harden lowering-plan v1

- Inventory every remaining source-name, profile-name, substring, boolean flag
  and handwritten allowlist across Flowanalyst, Flowbind, Flowparallel,
  Flowoptimize and Flowlower.
- Verify the versioned lowering-plan schema and reject malformed, blocked,
  incompatible or unsupported plans.
- Make Flowbind authorize each external operation by exact provider and ABI
  contract facts. Bind authorization to the generated contract/evidence identity
  rather than symbol existence alone.
- Add positive, negative and adversarial contract tests.

### Gate 2 — Preserve the generic plan across the middle stages

- Make Flowparallel consume and publish the generic operation plan without
  application-profile allowlists.
- Make Flowoptimize preserve operation identity, ordering constraints,
  provenance, effects and authorization evidence.
- Reject silent operation loss, mutation without provenance, and incompatible
  plan versions.

### Gate 3 — Implement reusable lowering

- Implement generic lowering for the currently supported literals, variables,
  assignments, call arguments, result placement and return values.
- Implement generic external calls for the established integer, size, long,
  unsigned-long, string and opaque-pointer ABI carriers.
- Implement the language control flow required by the existing examples and
  `flow_less`, driven by structured AST/semantic facts.
- Validate argument count/types, result type, convention, effects and
  authorization before emitting LLVM.
- Produce structured failure reports for unsupported language or ABI features.
- Do not identify applications by filenames, source-unit names or profile names.

### Gate 4 — Prove profile independence

- Migrate the current native examples onto the generic path while keeping their
  observable behavior and gates green.
- Add one new external scalar capability and one newly named Flow program as an
  acceptance proof.
- Build the new program using already-built Flowcore binaries.
- Prove that the acceptance program and binding require zero C++ compiler source
  changes and no toolchain rebuild.
- Remove corresponding legacy profile branches only after equivalent positive,
  negative, adversarial and native-execution coverage passes.

### Gate 5 — Repair known correctness gaps

- Represent imported short-name resolution with a candidate set or permanent
  ambiguity state. Test one, two, three and more providers exporting the same
  name. Qualified calls must remain stable.
- Retain unqualified imported calls only as clearly diagnosed compatibility
  behavior, with a documented removal path.
- Make `sel` behavior source-derived rather than profile-derived.
- Repair its read buffer handling: reserve terminator space; never use a negative
  result as an offset; distinguish error, EOF and positive reads; cover the paths
  with tests.
- Model ncurses resource ownership/lifetime and cleanup sufficiently to prevent
  successful paths from concealing invalid generic pointer behavior.

### Gate 6 — Implement `flow_less` and real `=>` semantics

- Implement `flow_less` as Flow-owned pager behavior with injectable input,
  terminal and output providers.
- Preserve complete source and destination port identity through validation,
  planning, lowering and runtime delivery.
- Assign wire and signal identities and carry their provenance into diagnostics.
- Exercise `=>` as graph connection, not sequential-call syntax.
- Test ordering, fan-out, unconnected-output laws, failure propagation, input
  selection and observable results.
- Keep scheduling delivery policy separate from the receiving node/plug
  activation contract.

### Gate 7 — Final hardening and reconciliation

- Run focused tests during each slice.
- Run the complete canonical build and CTest suite at major boundaries.
- Run available sanitizer, malformed-input, native-link and native-execution
  gates.
- Reconcile README, architecture notes, checkpoint ledger, test counts and PR
  metadata descriptions that live in the repository. Do not merge the PR.
- Document remaining platform limitations honestly; do not describe a
  handwritten or fixture-specific path as generic.
- Ensure generated files are reproducible and no transient build/log artifacts
  are committed.

## Checkpoint protocol

At each coherent boundary:

1. Run the focused gate and `git diff --check`.
2. Run the complete suite when a public contract or stage boundary changes.
3. Update the maturation ledger with confirmed behavior, evidence, temporary
   compatibility, remaining work and the exact next action.
4. Inspect the diff for unrelated changes and accidental generated output.
5. Commit with a descriptive message and push the current development branch.
6. Leave `.codex-run-state` as `CONTINUE` and proceed immediately.

Do not create empty checkpoint commits. Do not commit failing states unless a
preserved diagnostic fixture is itself the intended, documented checkpoint.

## Definition of done

Set `.codex-run-state` to `DONE` only when all of the following are true:

- Every required compiler stage consumes the versioned generic plan without
  application/source-name profile selection.
- No migrated example depends on a handwritten application-specific LLVM
  emitter.
- Exact capability/ABI authorization is verified end to end.
- A newly named acceptance program using a newly selected binding compiles with
  the already-built binaries and without C++ changes or rebuilding Flowcore.
- `sel` is source-faithful and its read/error paths are safe.
- Namespace ambiguity tests cover at least one, two and three colliding
  providers.
- `flow_less` owns its application semantics in Flow source.
- The required `=>` port, wire, signal, fan-out, failure and scheduling behaviors
  are executable and covered by tests.
- The complete build, tests, sanitizer gates and native execution demonstrations
  pass.
- Documentation and recorded test counts match the verified checkout.
- Transitional profile machinery covered by the mission is removed or an
  explicitly approved semantic blocker is recorded. Ordinary remaining work is
  not a deferral.
- The final ledger records exact commands and results, the final commit is
  pushed, and the worktree is clean.

The final report must include the commit range, gates and counts, the profile-free
acceptance demonstration, native artifact evidence, remaining explicitly scoped
platform limitations, and confirmation that the branch is pushed and clean.

## Blocked state

Set `.codex-run-state` to `BLOCKED` only if all safe work is prevented. Before
doing so:

- attempt reversible alternatives;
- preserve passing work in a coherent checkpoint where possible;
- record the exact blocker and evidence in the maturation ledger;
- identify the smallest decision, credential or authority required from Henrik;
- do not disguise a large workload, failed test, ordinary design choice, or
  context limit as a blocker.
