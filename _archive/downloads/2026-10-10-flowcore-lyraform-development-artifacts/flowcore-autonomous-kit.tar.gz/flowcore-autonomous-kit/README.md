# Flowcore autonomous Codex kit

This kit turns the current reusable Flow compiler-chain task into a durable,
restartable Codex workflow. It is designed for the repository state described by
the 21 August 2026 maturation ledger: `flowcore.lowering_plan` v1 is emitted by
Flowanalyst, validated structurally by Flowbind, and the reported full suite is
52/52 passing. The first agent run must verify those facts against the actual
checkout before continuing.

## Included files

- `AGENTS.autonomous.append.md` — project rules to append to the repository's
  existing `AGENTS.md`.
- `docs/tasks/reusable-flow-chain-autonomous.md` — authoritative mission and
  definition of done.
- `.codex-run-state` — machine-readable continuation state, initially
  `CONTINUE`.
- `tools/run-autonomous-codex` — bounded supervisor that starts successive
  `codex exec` runs until the mission reports `DONE` or a genuine `BLOCKED`
  state.

## Install into Flowcore

Run these steps from the Flowcore repository root.

1. Copy the task, state, and runner into the matching repository paths:

   ```bash
   cp /path/to/flowcore-autonomous-kit/.codex-run-state .
   mkdir -p docs/tasks tools
   cp /path/to/flowcore-autonomous-kit/docs/tasks/reusable-flow-chain-autonomous.md docs/tasks/
   cp /path/to/flowcore-autonomous-kit/tools/run-autonomous-codex tools/
   chmod +x tools/run-autonomous-codex
   ```

2. If the repository has an `AGENTS.md`, append the contents of
   `AGENTS.autonomous.append.md` after reviewing it. If no `AGENTS.md` exists,
   copy the fragment as `AGENTS.md`.

3. Inspect the installation:

   ```bash
   git diff --check
   git status --short
   bash -n tools/run-autonomous-codex
   tools/run-autonomous-codex --help
   ```

4. Confirm that the current branch has a configured remote and can push without
   an interactive password prompt:

   ```bash
   git branch --show-current
   git remote -v
   git push --dry-run
   ```

5. Commit the automation contract before launching it. This gives the agent a
   stable recovery point:

   ```bash
   git add AGENTS.md .codex-run-state docs/tasks/reusable-flow-chain-autonomous.md tools/run-autonomous-codex
   git commit -m "Add autonomous reusable-chain execution contract"
   git push
   ```

## Run while you do something else

Do not run this supervisor at the same time as another Codex session editing the
same checkout. Let the current turn finish or stop it cleanly first. If parallel
agent work is later desired, give each agent its own Git worktree and branch.

The default mode uses `workspace-write`, enables network access, and routes
eligible escalations through Codex auto-review. Start it in `tmux`:

```bash
tmux new-session -d -s flowcore-agent -c "$PWD" './tools/run-autonomous-codex'
```

Inspect it later:

```bash
tmux attach -t flowcore-agent
```

Detach again with `Ctrl-b d`.

The runner writes transcripts below `/tmp/flowcore-codex-$UID` unless
`FLOWCORE_CODEX_LOG_DIR` names another directory.

## Useful controls

```bash
# Allow at most 12 separate Codex turns.
FLOWCORE_CODEX_MAX_ITERATIONS=12 ./tools/run-autonomous-codex

# Select a model explicitly.
FLOWCORE_CODEX_MODEL=gpt-5.6-sol ./tools/run-autonomous-codex

# Use a persistent log directory outside the repository.
FLOWCORE_CODEX_LOG_DIR=/path/to/logs ./tools/run-autonomous-codex
```

To stop cleanly, interrupt the runner with `Ctrl-C`. It does not rewrite Git
history or kill unrelated processes. Relaunching it resumes from the task,
ledger, Git history, worktree, and `.codex-run-state`.

## Isolated full-access mode

Inside a disposable VM or development container containing only the working
clone and minimum Git credentials, the runner can operate without sandbox
approval boundaries:

```bash
FLOWCORE_CODEX_PERMISSION_MODE=isolated-full ./tools/run-autonomous-codex
```

The runner deliberately refuses unknown permission modes. Do not use
`isolated-full` from a broad home-directory checkout.

## State meanings

- `CONTINUE`: work remains; launch another Codex turn.
- `BLOCKED`: a genuine user decision or unavailable authority prevents all safe
  progress. The reason must be recorded in the project ledger.
- `DONE`: every definition-of-done gate in the task file has passed, the final
  checkpoint is committed and pushed, and the worktree is clean.

The supervisor also stops after repeated no-progress turns or command failures.
Those guards prevent an agent from spending indefinitely on the same failed
approach.
