# Lyraform complex integration examples

Prepared for Henrik on 14 September 2026.

## Contents

- `sources/maintenance_dispatch.flow` — policy-driven work-order dispatch,
  prioritization, team capacity, overtime, and deferral.
- `sources/transaction_workflow.flow` — transaction state machine with
  commit, rollback, rejection, recovery, and a bounded event checksum.
- `INTEGRATION_README.md` — the examples-directory purpose, complexity rule,
  and deterministic result summaries.

## Verification performed

Both new programs passed the repository's five-program integration corpus:

```text
Flowmini -> Flowanalyst -> Flowparallel -> Flowoptimize
```

The compiler stages were built directly from the checked-out C++ sources
because CMake was unavailable in the packaging environment. `git diff --check`
also passed. The source checkout itself was not included in this archive.
