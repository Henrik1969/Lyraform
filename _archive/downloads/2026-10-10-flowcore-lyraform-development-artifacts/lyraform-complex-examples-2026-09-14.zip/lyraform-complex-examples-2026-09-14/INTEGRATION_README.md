# Integration programs

These programs are intentionally larger than the focused language probes.
Each combines several already-supported Flowmini features and is exercised
through the complete inspectable chain:

```text
Flowmini -> Flowanalyst -> Flowparallel -> Flowoptimize
```

They are integration evidence, not golden AST fixtures. The focused examples,
goldens, negative corpus, and firetests remain the authoritative checks for
individual language rules.

The current set covers:

- imported functions, refined values, lists, loops, and branching;
- nested loops, indexed arrays, matrix accumulation, and checksums;
- ABI declarations, records, shared functions, and multiple targets;
- policy-driven maintenance dispatch with parallel input columns, capacity
  accounting, urgent-case overtime, deferral, and a stable summary;
- a command-driven transaction workflow with explicit state transitions,
  commit/rollback behavior, invalid-command recovery, and an event checksum.

## Complexity rule

An integration example should describe a recognizable program, not merely put
more syntax in one file.  It should have several collaborating functions or
state transitions, a deterministic result, and enough internal structure that
a compiler-stage regression can lose real behavior while still accepting the
surface grammar.  Small single-feature probes continue to belong in `pass/` or
`ast/`.

## Deterministic summaries

The application-shaped examples finish by printing compact state summaries.
These values document the intended program behavior even while the integration
gate itself stops at the optimized artifact boundary.

| Program | Printed values, in order |
| --- | --- |
| `maintenance_dispatch.flow` | accepted `7`, deferred `1`, overtime `1`, team jobs `2 2 3`, team minutes `515 397 468`, priority checksum `470` |
| `transaction_workflow.flow` | balance `18`, pending `0`, revisions `2`, rejected `3`, rollbacks `1`, event checksum `857248` |
